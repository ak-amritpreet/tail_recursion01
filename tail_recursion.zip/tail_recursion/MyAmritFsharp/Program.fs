﻿printfn "Hello from Amritpreet Kaur !!"
printfn "Tail Recursion Testing !!"

let rec multiplicationforTAILRECUSION lst acc =
    match lst with
    | [] -> acc
    | head :: tail -> multiplicationforTAILRECUSION tail (acc * head)

let rec readNumbers count acc =
    match count with
    | 0 -> acc
    | _ -> 
        let number = System.Console.ReadLine() |> int
        readNumbers (count - 1) (number :: acc)

// Function to calculate product of list using tail recursion
let Final_Calculation () =
    printfn "Please enter 5 numbers and press ENTER after entering every number:"
    let myList = readNumbers 5 []
    let result = multiplicationforTAILRECUSION myList 1
    printfn "The final product is: %d" result

// Example usage:
Final_Calculation ()
